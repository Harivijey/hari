package com.hari.restful;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PostMapping;
@RestController
public class welcome {
	@PostMapping("/greeting")
	public Greeting run(@RequestBody Greeting u) {
		return new Greeting(1, u.name);
	}
}