package com.hari.restful;

public class Greeting {
	int id;
	String name;
	public Greeting(int id,String name) {
		this.id=id;
		this.name=name;
	}
	public String getEmail() {
		return "www.dhachanamoorthy3@gmail.com";
	}
	public String getName() {
		return name;
	}
}
