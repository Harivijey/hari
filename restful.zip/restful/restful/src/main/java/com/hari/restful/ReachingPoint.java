package com.hari.restful;

public class ReachingPoint {
	int sx,sy,tx,ty;
	private boolean result=false;
	public ReachingPoint(int sx,int sy,int tx,int ty) {
		this.sx=sx;
		this.sy=sy;
		this.tx=tx;
		this.ty=ty;
		result=reachingPoints(sx, sy, tx, ty);
	}
	public boolean reachingPoints(int sx, int sy, int tx, int ty) {
        int x=sx,y=sy;
        int flag=0;
        for(int i=0;i<2;i++){
            if(flag==0){
                flag=1;
            }
            else{
                flag=0;
            }
            while(x<=tx || y<=ty){
                if(flag==0){
                    x=x+y;
                    flag=1;
                }
                else{
                    y=x+y;
                    flag=0;
                }
                if(x==tx && y==ty){
                    return true;
                }
            }
        }
        return false;
    }
	public boolean getResult() {
		return result;
	}
}
