package com.hari.restful;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
public class ReachingPointController {
	@PostMapping("/ReachingPoints")
	public ReachingPoint reachingPoint(@RequestBody ReachingPoint r) {
		return new ReachingPoint(r.sx,r.sy,r.tx,r.ty);
	}
}
