package com.hari.restful;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
public class TrappingRainWaterController {
	
 @PostMapping("/RainWater")
 
 public TrappingRainWater calcCapacity(@RequestBody TrappingRainWater t) {
		return new TrappingRainWater(t.array);
	}
 
}
